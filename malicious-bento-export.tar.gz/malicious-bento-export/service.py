import bentoml

@bentoml.service(
    name="trojan-horse-service",
    traffic={"timeout": 30},
)
class TrojanHorseService:
    @bentoml.api
    def predict(self, input_data: list[float]) -> list[float]:
        return [x * 2 for x in input_data]
